FREELANCE CONTRACT SUITE — 3-TAB DIGITAL FORM & WORD BUNDLE
===========================================================
Included in this package:
1. Contract-Suite-3-Tabs.html          -> Interactive 3-in-1 Web & Offline Contract Form
2. Combined-3-Tab-Contract-Suite.docx  -> Combined Editable Microsoft Word Master Document
3. README.txt                          -> Step-by-Step User Guide & Legal Disclaimer

1. HOW TO USE THE 3-TAB HTML FORM (Contract-Suite-3-Tabs.html)
--------------------------------------------------------------
- Open `Contract-Suite-3-Tabs.html` in any web browser (Google Chrome, Microsoft Edge, Apple Safari, or mobile browser). No internet connection or software installation is required.
- Step 1 (Fill Shared Details Once): At the top panel ("Party / Employee / Contractor & Client Details"), enter the Freelancer/Employee/Provider Name, Address, Effective Date, Client Name, Client Address, Governing Law, and Signatory Names/Titles. These details automatically sync across all three tabs.
- Step 2 (Switch Between the 3 Tabs):
  * Tab 1: Mutual NDA — Customize term length, notice period, and confidentiality survival period.
  * Tab 2: Independent Contract — Fill in Project Name, Deliverables (1–3), Start/Completion Dates, Hourly/Fixed Fee, Deposit %, Milestones, Net Payment Days, Late Fee %, Revision Rounds, and Termination Notice.
  * Tab 3: Payment Terms — Enter Bank/Wire Transfer (ACH) details, Online Payment processor (e.g., Stripe / PayPal), Net Payment Days, Late Fee %, and Suspension Days.
- Step 3 (Automatic Offline Saving): Everything you type is saved automatically in your browser (`localStorage`). Click "Clear Fields" in the top bar whenever you want to reset the form for a new client.

2. HOW TO PRINT, SAVE AS PDF, OR EXPORT TO WORD
-----------------------------------------------
- Print / Save as PDF: Click "Print / Save PDF" in the top bar (or press Ctrl+P on Windows / Cmd+P on Mac) and select "Save as PDF" or your printer. Toolbars and input borders are hidden automatically so the printout matches a clean legal contract.
- Export to Microsoft Word:
  * Click "Download Word (Active Tab)" to save only the currently open tab as a populated `.doc` file.
  * Click "Download Word (All 3 Tabs)" to export all three completed agreements into a single multi-page Word document.
  * You can also open `Combined-3-Tab-Contract-Suite.docx` directly in Microsoft Word or Google Docs for manual editing.

3. IMPORTANT LEGAL DISCLAIMER
-----------------------------
The templates included in this bundle are provided for general business and informational purposes only and do not constitute formal legal advice. Neither the creator nor the seller acts as your legal counsel. Laws vary by state, country, and industry—please consult a licensed local attorney to review your finalized documents before signing.
