# THE ULTIMATE FREELANCER & SMALL BUSINESS TOOLKIT
## User Guide & Operational Manual

---

### EXECUTIVE OVERVIEW

Welcome to **The Ultimate Freelancer & Small Business Excel & Google Sheets Bundle**. This document serves as your complete user manual and operational guide for managing your financial records, client workflows, budget allocations, and billing systems.

The bundle consists of four interconnected digital assets:
1. **Invoice & Quotation Template**
2. **Income & Expense Tracker**
3. **Monthly Budget Planner**
4. **Client Project Tracker**

---

## SECTION 1: INVOICE & QUOTATION TEMPLATE

### 1.1 Overview & Structure
The Invoice & Quotation Template provides a professional, automated invoicing framework designed for quick client billing and formal project quotes.

* **Format:** Single-sheet printable template (A4 Portrait pre-calibrated).
* **Automated Calculations:** Line item subtotaling, configurable tax calculation, discount deduction, and dynamic due date computing.

### 1.2 Layout & Cell Mapping

| Cell Range | Block Name | Purpose / Function | Formula / Logic |
| :--- | :--- | :--- | :--- |
| `A1:D3` | Business Branding | Company Name, Tagline, Address, Contact details | Static text |
| `F1:H2` | Document Header | Header toggle (`INVOICE` or `QUOTATION`) | Static header |
| `F3:H5` | Invoice Metadata | Invoice Number, Issue Date, Due Date | `G5: =G4+14` |
| `A6:D8` | Client Information | Client Name, Company, Billing Address | Static text |
| `A10:H10` | Line Item Headers | Item No., Description, Qty, Unit Rate, Line Total | Header row |
| `A11:H20` | Line Items (10 rows) | Billable services or physical items | `H11: =IF(ISBLANK(F11), "", F11*G11)` |
| `F21:H24` | Summary Totals | Subtotal, Tax Rate %, Tax Amount, Discount, Total Due | See Section 1.3 |
| `A21:E24` | Payment Terms | Wire Transfer details, Payment Terms, Bank Info | Static text |

### 1.3 Key Formulas Breakdown

* **Line Item Total (`H11:H20`)**:
  ```excel
  =IF(ISBLANK(F11), "", F11*G11)
  ```
  *Explanation:* Evaluates whether the Quantity field (`F11`) contains a value. If blank, the line total remains completely clear rather than displaying `$0.00`. If populated, it multiplies Quantity by Unit Rate (`G11`).

* **Subtotal (`H21`)**:
  ```excel
  =SUM(H11:H20)
  ```
  *Explanation:* Sums all non-blank item totals across the billable lines.

* **Tax Calculation (`H22`)**:
  ```excel
  =H21 * G22
  ```
  *Explanation:* Multiplies the Subtotal (`H21`) by the Tax Percentage entered in cell `G22` (e.g., `10%` or `0.10`).

* **Total Amount Due (`H24`)**:
  ```excel
  =H21 + H22 - H23
  ```
  *Explanation:* Adds the Tax Amount (`H22`) to the Subtotal (`H21`) and subtracts any manually entered Discount (`H23`).

---

## SECTION 2: INCOME & EXPENSE TRACKER

### 2.1 Overview & Structure
The Income & Expense Tracker serves as your central cash flow register. It tracks all incoming client payments and outgoing operational costs while maintaining an automated running bank balance.

### 2.2 Key Performance Indicator (KPI) Header

* **Total Income (`A3:B4`)**: Sums all positive cash inflows.
  ```excel
  =SUM(D7:D1000)
  ```
* **Total Expenses (`C3:D4`)**: Sums all operational outlays.
  ```excel
  =SUM(E7:E1000)
  ```
* **Net Cashflow (`E3:F4`)**: Displays net operational profit/loss.
  ```excel
  =B4 - D4
  ```

### 2.3 Running Balance Logic

* **Row 1 Entry (`F7`)**:
  ```excel
  =D7 - E7
  ```
* **Subsequent Entries (`F8` through `F1000`)**:
  ```excel
  =IF(AND(ISBLANK(D8), ISBLANK(E8)), "", F7 + N(D8) - N(E8))
  ```
  *Technical Note:* The `N()` function ensures string values or empty inputs evaluate safely to zero, preventing calculation errors down the sheet.

---

## SECTION 3: MONTHLY BUDGET PLANNER

### 3.1 Overview & Structure
The Monthly Budget Planner enables proactive expense management by comparing target spending allocations against actual disbursements across 15 standard business categories.

### 3.2 Category & Formula Breakdown

| Category Name | Planned ($) | Actual ($) | Variance ($) | Status Formula |
| :--- | :--- | :--- | :--- | :--- |
| **Software & Subscriptions** | `B6` | `C6` | `=C6-B6` | `=IF(C6=0, "No Spend", IF(C6>B6, "Over Budget", "Within Budget"))` |
| **Marketing & Advertising** | `B7` | `C7` | `=C7-B7` | Same formula as above |
| **Office Rent / Workspace** | `B8` | `C8` | `=C8-B8` | Same formula as above |
| **Utilities & Internet** | `B9` | `C9` | `=C9-B9` | Same formula as above |
| **Subcontractors & Freelancers**| `B10` | `C10` | `=C10-B10` | Same formula as above |
| **Legal & Professional Fees** | `B11` | `C11` | `=C11-B11` | Same formula as above |
| **Equipment & Hardware** | `B12` | `C12` | `=C12-B12` | Same formula as above |
| **Payment Processing Fees** | `B13` | `C13` | `=C13-B13` | Same formula as above |
| **Travel & Client Meals** | `B14` | `C14` | `=C14-B14` | Same formula as above |
| **Miscellaneous Expenses** | `B15` | `C15` | `=C15-B15` | Same formula as above |

### 3.3 Variance & Status Interpretation
* **Positive Variance (`> $0.00`)**: Indicates actual spending exceeded planned budget (Over Budget).
* **Negative Variance (`< $0.00`)**: Indicates spending came in below allocation (Under Budget / Savings).
* **Zero Variance (`= $0.00`)**: Exact budget adherence.

---

## SECTION 4: CLIENT PROJECT TRACKER

### 4.1 Overview & Structure
The Client Project Tracker unites project management and receivables tracking into a single operational sheet.

### 4.2 KPI Summary Metrics
* **Total Projects (`B3`)**: Counts total project entries.
  ```excel
  =COUNTA(A6:A500)
  ```
* **Active Projects (`D3`)**: Counts projects actively in flight.
  ```excel
  =COUNTIF(D6:D500, "In Progress")
  ```
* **Outstanding Receivables (`F3`)**: Sums contract values for projects where payment is unpaid or partial.
  ```excel
  =SUMIF(F6:F500, "<>Paid", G6:G500)
  ```

### 4.3 Data Validation Lists

1. **Project Status (`Column D`)**:
   * Options: `Not Started` | `In Progress` | `On Hold` | `Done`
2. **Payment Status (`Column F`)**:
   * Options: `Unpaid` | `Partial` | `Paid`

---

## SECTION 5: STYLING & BRANDING SPECIFICATIONS

### 5.1 Color Palette Palette
To maintain a professional aesthetic suitable for selling as a digital product, apply the following hexadecimal color parameters:

* **Dark Charcoal Header Fill:** `#1E293B`
* **Header Text Color:** `#FFFFFF` (Bold)
* **Summary KPI Card Fill:** `#F1F5F9`
* **Table Gridlines:** `#E2E8F0`
* **Positive Status (Paid / Within Budget):** Background `#DCFCE7`, Text `#166534`
* **Pending Status (In Progress / Partial):** Background `#FEF9C3`, Text `#854D0E`
* **Alert Status (Unpaid / Over Budget):** Background `#FEE2E2`, Text `#991B1B`

### 5.2 Print & Export Setup
1. **Paper Size:** A4 or US Letter.
2. **Orientation:** 
   * Portrait for *Invoice & Quotation Template*.
   * Landscape for *Income & Expense Tracker*, *Monthly Budget Planner*, and *Client Project Tracker*.
3. **Scaling:** Select **Fit All Columns on One Page** prior to exporting to PDF.