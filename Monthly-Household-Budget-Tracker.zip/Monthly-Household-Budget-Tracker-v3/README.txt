MONTHLY HOUSEHOLD BUDGET & SAVINGS GOAL TRACKER (v3 - INTERNATIONAL EDITION)
=============================================================================
Included in this package:
1. index.html      -> Complete Web & Mobile App (12-Month Memory + Yearly Dashboard + Offline/Online Support)
2. template.xlsx   -> Excel & Google Sheets Workbook (Yearly Dashboard with Chart + 12-Month Ledger + Budgets)
3. README.txt      -> Quick Start, Mobile App Installation & Backup Guide

1. HOW TO USE THE APP (index.html)
----------------------------------
- Open `index.html` in Google Chrome, Microsoft Edge, or Apple Safari (on PC, Mac, Android, or iPhone).
- Step 1 (Choose Currency): Select your currency from the top bar (USD $, EUR €, GBP £, CAD C$, AUD A$, AED, SAR, PKR, INR ₹, JPY ¥). All currency symbols and input fields update immediately—your entered numbers are stored directly in your chosen currency without hidden conversion math.
- Step 2 (Start Clean): Click "Start Fresh (Clear Demo)" on the top blue bar to clear the demo numbers before entering your own data.
- Step 3 (Monthly Tracking): Select the Year and Month, add your Income and Daily Expenses (with 12 built-in daily categories + Custom Category creator), set Monthly Category Limits, and track Savings Goals.
- Step 4 (Yearly Overview): Switch to the "Yearly Overview" tab anytime to view your full 12-month bar chart, month-by-month ledger, and annual category breakdown.
- Step 5 (Monthly Cleanup & Backups): At the start of a new month, simply switch the Month dropdown—your previous months stay safely archived for the Yearly Dashboard, while your Category Budget Limits and Savings Goals carry forward automatically. Use "Clear This Month" if you ever want to wipe only the current month's entries, and click "Export Backup" to download a JSON backup file.

2. INSTALL ON MOBILE HOME SCREEN (ANDROID & IPHONE)
---------------------------------------------------
- Android (Chrome / Edge): Open via your web link and tap "Install App" in the header (or browser menu ⋮ -> "Add to Home screen / Install app").
- iPhone / iPad (Safari): Open in Safari -> tap the Share icon -> tap "Add to Home Screen" -> tap "Add". The app icon will appear on your home screen.

3. HOW TO USE THE SPREADSHEET (template.xlsx)
---------------------------------------------
- Open `template.xlsx` in Microsoft Excel or upload it to Google Drive and open with Google Sheets.
- Log entries in the `Monthly Transactions` tab using the Month and Category dropdowns, customize monthly limits in `Budgets & Goals`, and view your 12-month chart and totals in `Yearly Dashboard`.
