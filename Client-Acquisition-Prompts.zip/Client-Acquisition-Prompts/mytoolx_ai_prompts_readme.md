# MytoolX AI prompts — Client Acquisition & Sales Prompt Vault

A clean, fast, and interactive web application housing **100 engineered AI prompts** for client acquisition, outreach, proposals, discovery calls, objection handling, and client retention. Designed to run seamlessly both locally in any browser and hosted live on your domain.

---

## 📦 Package Contents

* **`index.html`** — Main entry file ready for direct web hosting (Netlify, Vercel, GitHub Pages, cPanel, or any static host).
* **`MytoolX-AI-Prompts.html`** — Standalone single-file version with identical functionality for offline or desktop use.
* **`README.md`** — Documentation, category breakdown, hosting instructions, and prompt usage guide.

---

## ✨ Key Features

* **7 Organized Workflow Categories:** Browse all 100 prompts cleanly structured by sales stage and business workflow.
* **Frictionless Navigation & Return Home:** Sticky navigation bar (**Home**, **All 100 Prompts**, **Saved**), interactive breadcrumb trail, category filter pills, per-card **↑ Home** shortcuts, and a floating **↑ Top** scroll button.
* **Instant Live Search:** Filter prompts in real time by prompt number (`#1`–`#100`), title, category, role, or keyword (e.g., *Upwork*, *cold email*, *retainer*, *objection*).
* **Interactive Variable Filler (`✏️ Fill Variables`):** Automatically detects every bracketed placeholder (e.g., `[insert target industry]`) and provides a live input modal so you can customize and preview your prompt before copying.
* **One-Click Copy (`📋 Copy Prompt`):** Copies clean, unformatted prompt text directly to your clipboard ready for ChatGPT, Claude, DeepSeek, or Gemini.
* **Offline Bookmarking (`⭐ Save`):** Save your most-used prompts in your browser (`localStorage`) for instant access anytime—no login or database required.

---

## 🗂️ Prompt Category Directory (100 Prompts)

| Category | Count | Prompt Range / Focus Areas |
| :--- | :---: | :--- |
| **1. Cold Outreach & Lead Generation** | 26 | Hyper-personalized cold emails, PAS frameworks, Loom audit teasers, trigger-event sequences, cold calls, voicemails, and LinkedIn/DM openers. |
| **2. Proposals, Upwork & Pitching** | 13 | Hook-first Upwork bids, rapid-response proposals, high-ticket consultant & tech architecture proposals, 3-tier pricing, and executive summaries. |
| **3. Discovery Calls & Qualification** | 11 | 15-minute discovery agendas, pain-point question banks, inbound qualification & scoring, persona research, battlecards, and pre/post-call recaps. |
| **4. Objection Handling & Closing** | 9 | Premium price anchoring, cheaper agency counters, budget phasing, spec-work refusal, concession ladders, and contract clarifications. |
| **5. Follow-Up & Lead Reactivation** | 10 | 48-hour follow-ups, "think about it" sequences, multi-channel un-ghost campaigns, no-show recovery, breakup emails, and dormant lead reactivation. |
| **6. Conversion Copy & Social Proof** | 12 | Website hero variations, sales & pricing pages, lead magnet funnels, case studies, testimonial requests, bios, and value propositions. |
| **7. Partnerships, Retention & Upsells** | 19 | White-label & strategic alliances, podcast/speaking pitches, referral incentives, retainer conversions, onboarding handoffs, and client retention. |

---

## 🚀 How to Run & Host

### Option 1: Run Offline on Your Computer
1. Extract the ZIP archive (`MytoolX-AI-Prompts-Web-Package.zip`).
2. Double-click **`MytoolX-AI-Prompts.html`** (or `index.html`) to open it in Google Chrome, Microsoft Edge, Apple Safari, or any mobile browser.
3. No internet connection, server, or installation is required.

### Option 2: Publish Online to Your Website
1. Upload **`index.html`** to the root folder (`public_html` or `www`) of your web host, or drag-and-drop the folder onto **Netlify**, **Vercel**, or **GitHub Pages**.
2. Your **MytoolX AI prompts** directory will be immediately live and mobile-responsive.

---

## 🛠️ How to Use the Prompts Effectively

1. **Locate a Prompt:** Select a workflow category card on the Home screen or type a keyword into the search bar.
2. **Customize Bracketed Variables:** Click **`✏️ Fill Variables`** on any prompt card to enter your specific niche, client role, offer, or metric—or click **`📋 Copy Prompt`** to copy the template as-is.
3. **Paste & Execute:** Paste the prompt into your preferred AI workspace (ChatGPT, Claude, Gemini, or DeepSeek) and review the generated output before sending to prospects or clients.

---

## ⚠️ Disclaimer

AI-generated outputs should always be reviewed, fact-checked, and tailored to your authentic voice and client context before publishing or sending outreach messages.